# encoding:utf-8

import numpy as np 
import matplotlib.pyplot as plt
import scipy.io as scio
import Function as F
import time
showFlag = False

# 导入数据
# waiting~
dataFile = '100_node_Chen.mat'
data = scio.loadmat(dataFile)

print "data =", data
sequencenumber = data['sequencenumber']
# plt.scatter(sequencenumber[0], sequencenumber[1], s = 1, color = 'k')
if showFlag is True:
	plt.show()



# 主要参数
nodeNum = sequencenumber[0].shape[0] 	# 节点个数
print "nodeNum =", nodeNum


dim = 2 	  	# 样本数据为2维
k = 4		  	# 分区个数
X = 100
Y = 100 		# 网络覆盖范围



# 二次分区实验:
# 1、以子区域中心点为参考点，求得与之最近的点作为中心点(求每个点到区域中心的距离)
# 2、已获得中心点，求整个网络传感器节点到k个网络中心的最短路由和距离
# 求 W = alpha*D + beta*H，以最小W为准，将传感器节点划分到对应的分区内
Area = []		 	# 分区之后，节点坐标
Routing = np.empty([1, 100], dtype = list)		# 分区之后，路由结果

Distance_partition = np.empty([1, k], dtype = list)	# 分区之后，节点之间距离
centerpoint = np.zeros([3, k], dtype = np.float32) # 中心点坐标
findminDistance = np.empty([1, k], dtype = list)    # 存储一个区域内节点到所有节点的距离之后
					# 用于找到距离之和最小的节点
print "Area =", Area
print "Routing =", Routing
print "Distance_partition =", Distance_partition
print "centerpoint =", centerpoint
print "findminDistance =", findminDistance
# 将网络初始均分为k块
# 区域1，坐标范围为x = [0, 50], y = [0, 50]
region1 = 0
region1_list = []
# 节点标号
region1_nodeNum = []
# 节点横坐标
region1_coordinateX = []
# 节点纵坐标
region1_coordinateY = []

# 区域2，坐标范围为x = [0, 50], y = [50, 100]
region2 = 0
region2_list = []
# 节点标号
region2_nodeNum = []
# 节点横坐标
region2_coordinateX = []
# 节点纵坐标
region2_coordinateY = []

# 区域3，坐标范围为x = [50, 100], y = [50, 100]
region3 = 0
region3_list = []
# 节点标号
region3_nodeNum = []
# 节点横坐标
region3_coordinateX = []
# 节点纵坐标
region3_coordinateY = []

# 区域4，坐标范围为x = [50, 100], y = [0, 50]
region4 = 0
region4_list = []
# 节点标号
region4_nodeNum = []
# 节点横坐标
region4_coordinateX = []
# 节点纵坐标
region4_coordinateY = []


for i in range(0, nodeNum):
	# 判断X,Y坐标，若满足条件，则将其划分至一个区域内
	# 利用Area表示分区，sequencenumber中存储初始节点个数
	# 为保证公平性，内阁分区各占一条边
	# 属于区域1
	if((sequencenumber[0][i] <= 50)&(sequencenumber[1][i] < 50)):
		region1 = region1 + 1
		# 将节点标号、横坐标和纵坐标保存如区域region1中
		region1_nodeNum.append(i)
		region1_coordinateX.append(sequencenumber[0][i])
		region1_coordinateY.append(sequencenumber[1][i])
		# 作出第一类点的图形
		plt.scatter(sequencenumber[0][i], sequencenumber[1][i], s = 5, color = 'k', marker = 's')
	elif(sequencenumber[0][i] < 50)&(sequencenumber[1][i] >= 50):
		region2 = region2 + 1
		# 将节点标号、横坐标和纵坐标保存如区域region2中
		region2_nodeNum.append(i)
		region2_coordinateX.append(sequencenumber[0][i])
		region2_coordinateY.append(sequencenumber[1][i])
		# 作出第二类点的图形
		plt.scatter(sequencenumber[0][i], sequencenumber[1][i], s = 5, color = 'b', marker = 'h')
	elif(sequencenumber[0][i] >= 50)&(sequencenumber[1][i] > 50):
		region3 = region3 + 1
		# 将节点标号、横坐标和纵坐标保存如区域region3中
		region3_nodeNum.append(i)
		region3_coordinateX.append(sequencenumber[0][i])
		region3_coordinateY.append(sequencenumber[1][i])
		# 作出第三类点的图形
		plt.scatter(sequencenumber[0][i], sequencenumber[1][i], s = 5, color = 'r', marker = 'p')
	elif(sequencenumber[0][i] > 50)&(sequencenumber[1][i] <= 50):
		region4 = region4 + 1
		# 将节点标号、横坐标和纵坐标保存如区域region4中
		region4_nodeNum.append(i)
		region4_coordinateX.append(sequencenumber[0][i])
		region4_coordinateY.append(sequencenumber[1][i])
		# 作出第四类点的图形
		plt.scatter(sequencenumber[0][i], sequencenumber[1][i], s = 5, color = 'g', marker = '1')
# 区域1的数据归总
region1_list.append(region1_nodeNum)
region1_list.append(region1_coordinateX)
region1_list.append(region1_coordinateY)
# 区域2的数据归总
region2_list.append(region2_nodeNum)
region2_list.append(region2_coordinateX)
region2_list.append(region2_coordinateY)
# 区域3的数据归总
region3_list.append(region3_nodeNum)
region3_list.append(region3_coordinateX)
region3_list.append(region3_coordinateY)
# 区域4的数据归总
region4_list.append(region4_nodeNum)
region4_list.append(region4_coordinateX)
region4_list.append(region4_coordinateY)

# 整个网络区域数据归总
Area.append(region1_list)
Area.append(region2_list)
Area.append(region3_list)
Area.append(region4_list)

# 用于存储分区之后的节点个数
region = [region1, region2, region3, region4]
if showFlag is True:
	plt.show()

print "region[0] =", region[0]
print "region[1] =", region[1]
print "region[2] =", region[2]
print "region[3] =", region[3]

# 求每个区域内节点之间的距离，并将其存储在Distance_partition中
# 第一次均分
# 调用函数findDistance
regioncenterpoint = np.zeros([3, k], dtype = np.float32) # 网络中心点坐标
regioncenterpoint = [[0, 1, 2, 3],
					 [25, 25, 75, 75],
					 [25, 75, 75, 25]]
minDistance = np.empty([1, k], dtype = list)
for i in range(0, k):
	# 单个子区域中每个节点之间的距离
	Distance_partition[0][i] = F.findDistance(Area, i, region[i])
	# 求得传感器节点到区域中心的距离,这里假设区域中心为区域中点
	minDistance1 = F.FindDistanceByCenterpoint(sequencenumber, regioncenterpoint, i)
	minDistance[0][i] = minDistance1
print "minDistance =\n", minDistance
# np,show()
# Distance_partition =[[[第一分区的距离值][第二分区的距离值][第三分区的距离值][第四分区的距离值]]]
# 计算区域内距其他节点距离之和最小的节点作为初始中心点
# 挨个子分区找
for i in range(0, k):
	
	B = []
	# 统计子分区中每个节点到中心节点
	# for j in range(0, region[i]):
		# 用于表示该分区内节点间的距离
	#	A = Distance_partition[0][i]
		# findminDistance[i][j] = sum(A[j])
		# 统计节点j到所有其他节点的距离总和
	#	B.append(sum(A[j]))
	
	# 在list查找进行查找时，请使用index，而不是用find
	# 找到第i个区域的距离之和最小值
	# c = B.index(min(B))
	
	
	for j in range(0, nodeNum):
		A = minDistance[0][i]
		print"A[j] =\n", A[0][j]
		B.append(A[0][j])
	print "B =", B
	# np,show()
	c = B.index(min(B))
	print "c =", c
	for j in range(0, region[i]):
		if Area[i][0][j] == c:
			c = j
			break
	
	print "c =", c
	# print "Area =\n", Area
	# np,show()
	centerpoint[0][i] = Area[i][0][c]
	centerpoint[1][i] = Area[i][1][c]
	centerpoint[2][i] = Area[i][2][c]
	# 将中心点以圆形图标标红
	plt.scatter(Area[0][1], Area[0][2], s = 5, color = 'k', marker = 's')
	plt.scatter(Area[1][1], Area[1][2], s = 5, color = 'b', marker = 'h')
	plt.scatter(Area[2][1], Area[2][2], s = 5, color = 'r', marker = 'p')
	plt.scatter(Area[3][1], Area[3][2], s = 5, color = 'g', marker = '1')
	plt.scatter(centerpoint[1][i], centerpoint[2][i], s = 50, color = 'r')
# 查看区域中心
print "centerpoint =\n", centerpoint
# np,show()
if showFlag is True:
	plt.show()


# 以上为网络空间的均匀划分(第一次分区)


# 第二次分区过程
# 预处理路由矩阵，原用routing表示，现用routing_new表示
# 将.mat文件中的routing数据提取出来
routing_temp = data['routing']
# 为了在routing数据中加入无穷大inf，重新定义一个数组
routing_new = np.empty(routing_temp.shape, dtype = np.float32)
for i in range(0, routing_temp.shape[0]):
	for j in range(0, routing_temp.shape[0]):
		routing_new[i][j] = routing_temp[i][j]

for i in range(0, nodeNum):
	for j in range(0, nodeNum):
		# 对角线为0，其余位置初始为0的，先置为无穷大
		if(i != j)&(routing_new[i][j] == 0):
			# 置为无穷大
			routing_new[i][j] = float('inf')
print "routing_new =", routing_new
# 计算其他节点到中心点的分区最短路由
# 用minRouting进行存储(4行nodeNum列)
minRouting = np.empty([1, k], dtype = list)
minDistance = np.empty([1, k], dtype = list)
for i in range(0, k):
	minRouting1 = []

	# OneHop = []
	# 求得传感器节点到区域中心的路由长度
	minRouting1 = F.mydijkstra(routing_new, int(centerpoint[0][i]))
	# 按中心点统计到其他传感器节点的距离
	# minRouting1
	minRouting[0][i] = minRouting1
	# 求得传感器节点到区域中心的距离
	minDistance1 = F.FindDistanceByCenterpoint(sequencenumber, centerpoint, i)
	minDistance[0][i] = minDistance1
	# 查找minRouting中为1的值，该值的索引为节点i的邻居节点(满足1-hop的节点)
	# OneHop = find(minRouting1 == 1)
	# 判断OneHop的元素的个数，不够100个就补上0
	# for j in range(length(OneHop)+1, 100):
	#   OneHop(j) = 0
	# saveOneHoping(i, :) = OneHop	
# 已经得到每个传感器节点到k个区域中心的最短路由长度和距离
print "minRouting =", minRouting
print "minDistance =", minDistance
# 根据《李亚婷师姐提供的参数》
alpha = 0.5
beta = 0.5

for i in range(0, nodeNum):
	# i就为节点的标号
	# 每个节点到k个区域中心的距离
	minDistance
	# 每个节点到k个区域中心的路由长度
	minRouting
	# 首先排序
	D1 = [minDistance[0][0][0][i], 0]
	D2 = [minDistance[0][1][0][i], 1]
	D3 = [minDistance[0][2][0][i], 2]
	D4 = [minDistance[0][3][0][i], 3]
	D = []
	D.append(D1)
	D.append(D2)
	D.append(D3)
	D.append(D4)
	# print "D ", D
	# 对D进行排序
	F.select_sort(D)
	
	
	H1 = [minRouting[0][0][0][i], 0]
	H2 = [minRouting[0][1][0][i], 1]
	H3 = [minRouting[0][2][0][i], 2]
	H4 = [minRouting[0][3][0][i], 3]
	H = []
	H.append(H1)
	H.append(H2)
	H.append(H3)
	H.append(H4)
	# print "H ", H
	# 对H进行排序
	F.select_sort(H)
	# print "D ", D
	# print "H ", H
	W = [] 
	# 按区域提取，在统一区域进行判断
	for j in range(0, k):
		for m in range(0, len(D)):
			# 找出j区域中D的排序
			if D[m][1] == j:
				D_sort = m + 1 
				break
		for n in range(0, len(H)):
			# 找出j区域中H的排序
			if H[n][1] == j:
				H_sort = n + 1
				break
		# print "j =", j
		# print "D_sort =", D_sort
		# print "H_sort =", H_sort
		# 每个区域的权重
		W.append([alpha*D_sort + beta*H_sort, j])
		
	# print "W =", W
	F.select_sort(W)
	# 已经得出i节点属于W[0][0]区域
	# print "W =", W
	# print "W[0][1] =", W[0][1]
	if W[0][1] == 0:
		region1 = region1 + 1
		# 将节点标号、横坐标和纵坐标保存如区域region1中
		region1_nodeNum.append(i)
		region1_coordinateX.append(sequencenumber[0][i])
		region1_coordinateY.append(sequencenumber[1][i])
		# 作出第一类点的图形
		plt.scatter(sequencenumber[0][i], sequencenumber[1][i], s = 5, color = 'k', marker = 's')
	elif W[0][1] == 1:
		region2 = region2 + 1
		# 将节点标号、横坐标和纵坐标保存如区域region2中
		region2_nodeNum.append(i)
		region2_coordinateX.append(sequencenumber[0][i])
		region2_coordinateY.append(sequencenumber[1][i])
		# 作出第二类点的图形
		plt.scatter(sequencenumber[0][i], sequencenumber[1][i], s = 5, color = 'b', marker = 'h')
	elif W[0][1] == 2:
		region3 = region3 + 1
		# 将节点标号、横坐标和纵坐标保存如区域region3中
		region3_nodeNum.append(i)
		region3_coordinateX.append(sequencenumber[0][i])
		region3_coordinateY.append(sequencenumber[1][i])
		# 作出第三类点的图形
		plt.scatter(sequencenumber[0][i], sequencenumber[1][i], s = 5, color = 'r', marker = 'p')
	elif W[0][1] == 3:
		region4 = region4 + 1
		# 将节点标号、横坐标和纵坐标保存如区域region4中
		region4_nodeNum.append(i)
		region4_coordinateX.append(sequencenumber[0][i])
		region4_coordinateY.append(sequencenumber[1][i])
		# 作出第四类点的图形
		plt.scatter(sequencenumber[0][i], sequencenumber[1][i], s = 5, color = 'g', marker = '1')
for i in range(0, k):
	plt.scatter(centerpoint[1][i], centerpoint[2][i], s = 50, color = 'r')
print "分区对比实验~"
plt.show()


'''

# 基于传感器节点邻域相似度和节点之间距离的网络分区划分方案NP-NSD
# 1、求得传感器节点之间的相似度和距离
# 2、对相似度R和距离D进行排序
# 3、求B = 0.5*R+0.5*D，利用层次聚类按B进行对整个网络进行划分
Threshold_P = 2

# 网络中的节点坐标
sequencenumber = data['sequencenumber'] 
# 网络中的路由
routing_temp = data['routing']

# 节点之间的距离
Distance = data['Distance']

# 测试数据
'''
'''
nodeNum = 60
backFlag = True
if backFlag is True:
	sequencenumber = np.random.randint(0, 10, size = [2, nodeNum])
	
	routing_temp = np.zeros([nodeNum, nodeNum], dtype = np.int)
	for i in range(0, nodeNum):
		for j in range(i, nodeNum):
			if i == j:
				routing_temp[i][j]
			else:
				routing_temp[i][j] = np.random.randint(0, 2)
			routing_temp[j][i] = routing_temp[i][j]
	

	Distance = np.empty([nodeNum, nodeNum], dtype = np.float32)
	for i in range(0, nodeNum):
		for j in range(i, nodeNum):
			if i == j:
				Distance[i][j] = 0
			else:
				Distance[i][j] = np.sqrt(np.power(sequencenumber[0][i] - sequencenumber[0][j], 2) + 
					np.power(sequencenumber[1][i] - sequencenumber[1][j], 2))

			Distance[j][i] = Distance[i][j]

	

	np.savetxt('sequencenumber.txt', sequencenumber)
	np.savetxt('routing.txt', routing_temp)
	np.savetxt('Distance.txt', Distance)
else:
	sequencenumber = np.loadtxt('sequencenumber.txt', dtype = np.int)
	routing_temp = np.loadtxt('routing.txt', dtype = np.int)
	Distance = np.loadtxt('Distance.txt',dtype = np.float32)
'''
'''

print "sequencenumber =\n", sequencenumber
print "routing =\n", routing_temp
print "Distance = \n", Distance
# np,show()
# 为了在routing数据中加入无穷大inf，重新定义一个数组
routing_new = np.empty(routing_temp.shape, dtype = np.float32)
routing_new_temp = np.empty(routing_temp.shape, dtype = np.float64)
minRouting = np.empty([1, nodeNum], dtype = list)

for i in range(0, routing_temp.shape[0]):
	for j in range(0, routing_temp.shape[0]):
		routing_new[i][j] = routing_temp[i][j]
		routing_new_temp[i][j] = routing_temp[i][j]

for i in range(0, nodeNum):
	for j in range(0, nodeNum):
		# 对角线为0，其余位置初始为0的，先置为无穷大
		if(i != j)&(routing_new[i][j] == 0):
			# 置为无穷大
			routing_new[i][j] = float('inf')
# print "routing_new =", routing_new

# 求每个传感器到其余节点的路由长度
for i in range(0, nodeNum):
	# i 为传感器节点标号
	minRouting1 = F.mydijkstra(routing_new, i)
	# 将每个传感器节点到其余节点的路由长度进行保存
	minRouting[0][i] = minRouting1 
# print "minRouting =\n", minRouting

OneHopId = []
for i in range(0, nodeNum):
	# x为X中的值，i为x对应X中的Id,经过测试可用
	OneHopId.append([i for i, x in enumerate(minRouting[0][i][0]) if x == 1])

print "OneHopId =", OneHopId
r = np.identity(nodeNum)
print "r =\n", r
C = 0.8
for i in range(0, nodeNum):
	for j in range(i, nodeNum):
		OneHopId[i]
		OneHopId[j]
		if i == j:
			relationship = 1
		elif len(OneHopId[i]) == 0 or len(OneHopId[j]) == 0:
			relationship = 0
		else:
			relationship_2 = 0
			relationship_1 = (C/(len(OneHopId[i])*len(OneHopId[j])))
			for m in range(0, len(OneHopId[i])):
				for l in range(0, len(OneHopId[j])):
					relationship_2 = r[m][l] + relationship_2

			relationship = relationship_1*relationship_2
		# r(i, j) = r(j, i)
		r[i][j] = relationship
		r[j][i] = r[i][j]
print "r =\n", r
print "Distance =\n", Distance
R_list = []
D_list = []
data_num = 0
for j in range(0, nodeNum):
	for i in range(j + 1, nodeNum):
		R = [r[i][j], (i, j), data_num]
		D = [Distance[i][j], (i, j), data_num]
		# 将矩阵中的值进行统计
		R_list.append(R)
		D_list.append(D)
		# 计数加1
		data_num = data_num + 1
# print "R_list =\n", R_list[1:5]
# print "D_list =\n", D_list[1:5]
F.select_sort(R_list)
F.select_sort(D_list)
# print "R_list =\n", R_list[1:5]
# print "D_list =\n", D_list[1:5]
# 给矩阵中的值赋予序号
for j in range(0, len(R_list)):
	R_list[j].append((j+1))
	D_list[j].append((j+1))
print "R_list =\n", R_list
print "D_list =\n", D_list

B = np.zeros([nodeNum, nodeNum], dtype = np.float32)
B_list = []
for i in range(0, nodeNum):
	for j in range(0, nodeNum):
		B[i][j] = float('inf')

R_new = np.empty([nodeNum, nodeNum], dtype = list)
Distance_new = np.empty([nodeNum, nodeNum], dtype = list)
data_num = 0

# alpha决定路由的影响，beta决定距离的影响

alpha = 0.5
beta = 1.0 - alpha
for j in range(0, nodeNum):
	for i in range(j + 1, nodeNum):
		# 统一标号
		for m in range(0, len(R_list)):
			if R_list[m][2] == data_num:

				# print "R_list[m] =", R_list[m]
				# print "R_list[m][1] =", R_list[m][1]
				# print "R_list[m][1][0] =", R_list[m][1][0]
				# print "R_list[m][1][1] =", R_list[m][1][1]
				m
				# 只要得到m
				break
		for n in range(0, len(D_list)):
			if D_list[n][2] == data_num:
				# print "D_list[n] =", D_list[n]
				# print "D_list[n][1] =", D_list[n][1]
				# print "D_list[n][1][0] =", D_list[n][1][0]
				# print "D_list[n][1][1] =", D_list[n][1][1]
				n
				# 只要得到n
				break
		
		R_new[i][j] = R_list[m]
		Distance_new[i][j] = D_list[n]

		# print "R_new[i][j] =", R_new[i][j]
		# print "Distance_new[i][j] =", Distance_new[i][j]
		# print "R_new[i][j][3] =", R_new[i][j][3]
		# print "Distance_new[i][j][3] =", Distance_new[i][j][3]
		# print "(i, j) =", (i, j)
		B[i][j] = alpha*R_new[i][j][3] + beta*Distance_new[i][j][3]
		# print "B[i][j] =", B[i][j]
		
		B_temp = [B[i][j], (i, j), data_num]
		B_list.append(B_temp)
		# 继续往下查找
		data_num = data_num + 1

# print "R_new =", R_new
# print "Distance_new =", Distance_new
# print "B_list =\n", B_list
F.select_sort(B_list)
for j in range(0, len(B_list)):
	B_list[j].append((j+1))
# print "B_list =\n", B_list

# print "min(B_list) =", min(B_list)


# 为分区指标
# B[i][j]


# 聚类中心数量为4个
centerNum = 4

# 开始时，每个节点都是一个分类
cluster = []
for i in range(0, nodeNum):
	cluster_temp = []
	cluster_temp.append(i)
	cluster.append(cluster_temp)
# print "cluster =", cluster

# 开始时统计所有节点之间的距离
Distance_origin = np.empty([nodeNum, nodeNum], dtype = np.float32)
for j in range(0, nodeNum):
	for i in range(j, nodeNum):
		# Distance_origin[i][j] = np.sqrt(np.power(coordinate[0][i] - coordinate[0][j], 2) + np.power(coordinate[1][i] - coordinate[1][j], 2))
		# 对称矩阵
		# Distance_origin[j][i] = Distance_origin[i][j]
		if i == j:
			Distance_origin[i][j] = 0
		else:
			# 对称矩阵
			Distance_origin[i][j] = B[i][j]
			Distance_origin[j][i] = Distance_origin[i][j]

# print "B =\n", B
# print "Distance_origin =\n", Distance_origin
# np,show()
start_time = time.time()
# 总共分为4类
while len(cluster) != centerNum:
	# 用于统计类间距离
	Distance_leijian = np.empty([len(cluster), len(cluster)], dtype = np.float32)

	for i in range(0, len(cluster)):
		for j in range(i, len(cluster)):
			# cluster_i 和 cluster_j两个类
			cluster[i]
			cluster[j]
			# 统计类间元素间的距离
			Distance_element = []
			Distance_sum = 0.0
			for l in range(0, len(cluster[i])):
				for m in range(0, len(cluster[j])):
					# cluster_i 类中第l个元素
					cluster[i][l]
					# cluster_j 类中第m个元素
					cluster[j][m]
					# 追加类间元素的距离
					# Distance_element.append(np.sqrt(np.power(coordinate[0][cluster[i][l]] - coordinate[0][cluster[j][m]], 2) + np.power(coordinate[1][cluster[i][l]] - coordinate[1][cluster[j][m]], 2)))
					Distance_element.append(Distance_origin[cluster[i][l]][cluster[j][m]])
					Distance_sum = Distance_sum + Distance_origin[cluster[i][l]][cluster[j][m]]
					
			# 取类间最小距离，作为类间距离
			# Distance[i][j] = min(Distance_element)
			Distance_leijian[i][j] = Distance_sum/len(Distance_element)
			# 对称矩阵
			Distance_leijian[j][i] = Distance_leijian[i][j]

	# print "Distance =\n", Distance

	Distance_temp = []
	data_num = 0
	for j in range(0, len(cluster)):
		for i in range(j + 1, len(cluster)):
			Distance_temp.append([Distance_leijian[i][j], (i, j)])

	# print "Distance_temp =\n", Distance_temp

	# 对list进行从小到大排序
	F.select_sort(Distance_temp)
	# print "next cluster"
	# print "Distance_temp =\n", Distance_temp

	MaxDis = Distance_temp[-1][0]
	MinDis = Distance_temp[0][0]
	# print "Distance_temp[-1] =", Distance_temp[-1]
	# print "Distance_temp[0] =", Distance_temp[0]

	# print "MaxDis =", MaxDis
	# print "MinDis =", MinDis
	# Threshold = (MaxDis + MinDis)/Threshold_P
	# print "Threshold =", Threshold

	# 如果类间最小距离小于距离阈值，则将这两类进行合并
	# if MinDis <= Threshold:
	# MinDis = Distance_temp[0][0]
	# 表示第4类和第3类需要合并
	Two_cluster = Distance_temp[0][1] # (4, 3)
	for cluster_num in range(0, len(cluster[Two_cluster[0]])):
		cluster[Two_cluster[1]].append(cluster[Two_cluster[0]][cluster_num])
	cluster.remove(cluster[Two_cluster[0]])
end_time = time.time()
print "time =", (end_time - start_time), 's'
print "final_cluster =", cluster

# 将数据分成4个部分

coordinate = sequencenumber
# cluster = [[0], [1, 2], [3, 40, 8, 57, 6, 35, 99, 93, 10, 16, 24, 33, 36, 61, 63, 9, 86, 89, 12, 88, 22, 66, 76, 78, 13, 21, 38, 47, 77, 83, 90, 11, 69, 41, 51, 71, 85, 19, 67, 94, 59, 25, 49, 62, 80, 28, 84, 44, 55, 15, 39, 34, 73, 27, 60, 74, 64, 26, 58, 87, 50, 79, 32, 72, 52, 65, 56, 75, 4, 23, 30, 29, 54, 95, 96, 91, 98, 81], [5, 7, 20, 31, 43, 70, 17, 18, 42, 97, 14, 37, 45, 48, 92, 68, 82, 53, 46]]
'''
# for i in range(0, nodeNum):
# 	plt.text(sequencenumber[0][i], sequencenumber[1][i], i, fontsize = 10)
'''
for i in range(0, nodeNum):
	for j in range(i, nodeNum):
		if routing_temp[i][j] == 1:
			plt.plot([sequencenumber[0][i], sequencenumber[0][j]],[sequencenumber[1][i], sequencenumber[1][j]], c = 'k', linewidth = 0.1)


region0 = 0
region0_list = np.zeros([4, len(cluster[0])], dtype = np.float32)
data_sense0 = []

region1 = 0
region1_list = np.zeros([4, len(cluster[1])], dtype = np.float32)
data_sense1 = []

region2 = 0
region2_list = np.zeros([4, len(cluster[2])], dtype = np.float32)
data_sense2 = []

region3 = 0
region3_list = np.zeros([4, len(cluster[3])], dtype = np.float32)
data_sense3 = []

print "len(cluster[0]) =", len(cluster[0])
region0 = float(len(cluster[0]))
for i in range(0, len(cluster[0])):
	
	region0_list[0][i] = float(cluster[0][i] + 1)
	region0_list[1][i] = float(coordinate[0][cluster[0][i]])
	region0_list[2][i] = float(coordinate[1][cluster[0][i]])
	region0_list[3][i] = float(np.random.randint(80, 101))
	data_sense0.append(float(np.random.randint(1, 10)))
	plt.scatter(coordinate[0][cluster[0][i]], coordinate[1][cluster[0][i]], s = 40, c = 'r', marker = 's')

print "len(cluster[1]) =", len(cluster[1])
region1 = float(len(cluster[1]))
for i in range(0, len(cluster[1])):
	
	region1_list[0][i] = np.float64((cluster[1][i] + 1))
	region1_list[1][i] = np.float64(coordinate[0][cluster[1][i]])
	region1_list[2][i] = np.float64(coordinate[1][cluster[1][i]])
	region1_list[3][i] = np.float64(np.random.randint(80, 101))
	data_sense1.append(float(np.random.randint(1, 10)))
	plt.scatter(coordinate[0][cluster[1][i]], coordinate[1][cluster[1][i]], s = 40, c = 'k', marker = '*')

print "len(cluster[2]) =", len(cluster[2])
region2 = float(len(cluster[2]))
for i in range(0, len(cluster[2])):
	
	region2_list[0][i] = np.float64(cluster[2][i] + 1)
	region2_list[1][i] = np.float64(coordinate[0][cluster[2][i]])
	region2_list[2][i] = np.float64(coordinate[1][cluster[2][i]])
	region2_list[3][i] = np.float64(np.random.randint(80, 101))
	data_sense2.append(float(np.random.randint(1, 10)))
	plt.scatter(coordinate[0][cluster[2][i]], coordinate[1][cluster[2][i]], s = 40, c = 'b', marker = 'o')

print "len(cluster[3]) =", len(cluster[3])
region3 = float(len(cluster[3]))
for i in range(0, len(cluster[3])):
	region3_list[0][i] = np.float64(cluster[3][i] + 1)
	region3_list[1][i] = np.float64(coordinate[0][cluster[3][i]])
	region3_list[2][i] = np.float64(coordinate[1][cluster[3][i]])
	region3_list[3][i] = np.float64(np.random.randint(80, 101))
	data_sense3.append(float(np.random.randint(1, 10)))
	plt.scatter(coordinate[0][cluster[3][i]], coordinate[1][cluster[3][i]], s = 40, c = 'g', marker = 'x')
region = [region0, region1, region2, region3]
data_sense = []
data_sense.append(data_sense0)
data_sense.append(data_sense1)
data_sense.append(data_sense2)
data_sense.append(data_sense3)
Area = np.empty([1, 4], dtype = list)
Area[0][0] = np.float64(region0_list)
Area[0][1] = np.float64(region1_list)
Area[0][2] = np.float64(region2_list)
Area[0][3] = np.float64(region3_list)

plt.savefig('00004.png')
print "Area =\n", Area
plt.show()

# 最近两类最小距离为MinDis

dataMat = '100_node2_Area.mat'
LTSP = float(120)
scio.savemat(dataMat, {'Area': Area, 'routing': routing_new_temp, 
						'sequencenumber':data['sequencenumber'], 
						'Distance': data['Distance'],
						'LTSP': LTSP, 'region': region,
						'data_sense': data_sense})

dataFile = dataMat
NewData = scio.loadmat(dataFile)
print "NewData =\n", NewData
'''
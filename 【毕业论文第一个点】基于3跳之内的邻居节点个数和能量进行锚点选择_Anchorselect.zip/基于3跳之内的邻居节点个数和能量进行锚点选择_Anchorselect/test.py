# encoding: utf-8
import numpy as np 
'''
x = [0, 1, 3, float('inf')]
id_time = [i for i, x in enumerate(x) if x != float('inf')]
print "id_time =", id_time
'''
hehe = [0, 2, 4, 6, 7, 8, 10, 23, 25, 27, 29, 30, 31, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 44, 45, 46, 47, 48, 55, 57, 58, 59, 60, 61, 68, 70, 51]
connected = [14, 16, 20, 48, 51, 58, 61, 66]
for kk in range(0, len(hehe)):
	print "connected.index(hehe[kk])", connected.find(hehe[kk])
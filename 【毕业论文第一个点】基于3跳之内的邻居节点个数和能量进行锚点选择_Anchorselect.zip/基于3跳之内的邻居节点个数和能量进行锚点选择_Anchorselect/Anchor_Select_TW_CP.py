# encoding:utf-8
import numpy as np 
import matplotlib.pyplot as plt 
import scipy.io as scio
import Function as F
import random

# 导入数据
# waiting~
dataFile = 'adjustment_100.mat'
data = scio.loadmat(dataFile)
# print data
# 关键参数
k = 4 # 分区个数
sequencenumber = data['sequencenumber']
Area = data['Area']
region = data['region']
routing = data['routing']
print "len(Area) =", len(Area)
anchor_set = np.empty([1, k], dtype = list)

for i in range(0, k):

	if i == 0:
		
		# 作出第一类点的图形
		plt.scatter(Area[0][i][1], Area[0][i][2], s = 5, color = 'k', marker = 's')
		
	elif i == 1:
		
		# 作出第二类点的图形
		plt.scatter(Area[0][i][1], Area[0][i][2], s = 5, color = 'b', marker = 'h')
		
	elif i == 2:
		
		# 作出第三类点的图形
		plt.scatter(Area[0][i][1], Area[0][i][2], s = 5, color = 'r', marker = 'p')
		
	elif i == 3:
		
		# 作出第四类点的图形
		plt.scatter(Area[0][i][1], Area[0][i][2], s = 5, color = 'g', marker = '1')
		
plt.show()
path = np.empty([1, k], dtype = list) # 保存每个区域中节点之间的最短路由
X = np.empty([1, k], dtype = list) # 连通矩阵
x_hop = 3 # 表明节点之间k跳之内是否可达
Routing = np.empty([1, k], dtype = list) # 每个分区内路由情况
density = np.empty([1, k], dtype = list) # 保存节点密度

# 本文将能量百分比为85-100定义为level 1
# 70-85定义为level 2，剩下的定义为level 3
level_2 = np.empty([1, k], dtype = list)
# 存储邻域节点中的最小能量值
minEnergy = np.empty([1, k], dtype = list)
weight = np.empty([1, k], dtype = list) # 存储各区域中节点权重

alpha = 0.5
beta = 0.5

achor_set = np.empty([1, k], dtype = list) # 锚点集合
con_bran_all = np.empty([1, k], dtype = list) # 存储网络中连通分支

# 计算每个子区域的路由情况
for i in range(0, k):
	# 取出区域i
	zone = Area[0][i]
	# 求子区域路由情况
	yu_routing = np.empty([region[0][i], region[0][i]], dtype = np.int)

	# 遍历子区域中节点之间的路由情况
	for j in range(0, region[0][i]):
		for jj in range(0, region[0][i]):
			yu_routing[j][jj] = routing[zone[0][j] - 1][zone[0][jj] - 1]
	# 区域i的路由情况已经保存到Routing中了
	Routing[0][i] = yu_routing

# 构建子区域的连通矩阵
# 1、计算区域内节点之间的最短路由
for i in range(0, k):
	# 区域i中节点之间的路由
	# 为了在routing数据中加入无穷大inf，重新定义一个数组
	rou = np.empty([region[0][i], region[0][i]], dtype = np.float32)
	
	routing_new = Routing[0][i]
	
	# 由于原routing为uint，先转化为float
	for m in range(0, region[0][i]):
		for n in range(0, region[0][i]):
			rou[m][n] = routing_new[m][n]

	for m in range(0, region[0][i]):
		for n in range(0, region[0][i]):
			# 对角线为0，其余位置初始为0的，先置为无穷大
			if(m != n)&(rou[m][n] == 0):
				# 置为无穷大
				rou[m][n] = float('inf')

	# 临时矩阵用于保存区域i中节点间的路由情况
	path_final = np.empty([region[0][i], region[0][i]], dtype = np.int)
	for jjj in range(0, region[0][i]):
		# m1 为一个region[0][i]节点间的路由矩阵
		m1 = F.mydijkstra(rou, jjj)

		path_final[jjj] = m1
	# 保存区域i中节点间的路由长度
	path[0][i] = path_final

# 2、构建连通矩阵，表明m跳路由是否可达

for i in range(0, k):
	# 取出区域i中节点之间的路由表
	path_now = path[0][i]
	# 表示两节点之间是否在m跳内可达的连通矩阵
	X_now = np.zeros([region[0][i], region[0][i]], dtype = np.int)
	for j in range(0, region[0][i]):
		for jj in range(0, region[0][i]):
			# 两节点在x_hop跳内可达
			if (path_now[j][jj] <= x_hop) and (j != jj):
				X_now[j][jj] = 1
	X[0][i] = X_now

# 各区域中的连通矩阵已经构建完毕

# 计算节点密度，邻域节点个数/区域内节点总数
for i in range(0, k):
	X_new = X[0][i]
	density_temp = np.empty([1, region[0][i]], dtype = np.float32)
	for j in range(0, region[0][i]):
		# 计算节点j邻域节点个数，不需要判断，x_hop内的数值都为0
		# 需要强转float类型
		aa = float(sum(X_new[j]))
		density_temp[0][j] = aa/region[0][i]
	# 将区域i中节点的节点密度保存
	density[0][i] = density_temp

# 节点能量离散化
for i in range(0, k):
	# 1、为节点分配能量(初始时，随机值为80%~100%)
	energy = []
	# round(rand(m,n)*(b-a)) + a; m*n列，区间在[a,b]的随机值
	# energy = round(rand(1, region[0][i])*20) + 80
	# 随机生成20~80之间的数
	energy = np.random.uniform(20, 81, size = region[0][i])
	# 使用list为节点添加能量属性
	mmm_temp = []
	mmm = Area[0][i]
	for j in range(0, len(mmm)):
		mmm_temp.append(mmm[j])
	mmm_temp.append(energy)

	# 为区域i中的每个节点添加能量属性
	Area[0][i] = mmm_temp
	# print "Area[0][i] =\n", Area[0][i]

	# 2、节点能量离散化，并选择处于level 2的节点集合
	# 85 - 100 level 1； 70 - 85 level 2
	level_2_now = []
	# level_2_now = energy.index((energy >= 70)&(energy < 85))
	for j in range(0, region[0][i]):
		if energy[j] >= 70 and energy[j] < 85:
			# 需要-1，因为python环境与matlab的数组设置不太相同
			level_2_now.append(Area[0][i][0][j])
	# print "level_2_now =", level_2_now
	# 将能量处于level 2中的节点序号进行保存
	level_2[0][i] = level_2_now

# density[0][i] 节点的邻接节点密度
# Area[0][i] 第4个属性是能量
# 构建节点权重
for i in range(0, k):
	# 1、计算节点邻域集合中能量最小的节点能量值
	# 保存节点j邻域节点的最小能量值
	minEnergy_temp = np.zeros([1, region[0][i]], dtype = np.float32)
	weight_temp = np.zeros([1, region[0][i]], dtype = np.float32)
	
	# 将密度提取出来
	# print density[0][i]
	density_temp_new = density[0][i]
	# print "density_temp_new =\n", density_temp_new
	# print "density_temp_new[0][0] = \n", density_temp_new[0][0]
	# 将能量提取出来
	# print Area[0][i]
	energy_temp_new = Area[0][i][3] 
	# print "energy_temp_new =\n", energy_temp_new
	# print "energy_temp_new[0]=\n", energy_temp_new[0]
	
	for j in range(0, region[0][i]):
		# 密度排序
		density_sort = 0
		for density_j in range(0, region[0][i]):
			if density_temp_new[0][j] > density_temp_new[0][density_j]:
				density_sort = density_sort + 1
		# 当前密度排序 density_sort 和密度值
		[density_temp_new[0][j], density_sort]

		# 能量排序
		energy_sort = 0
		for energy_j in range(0, region[0][i]):
			if energy_temp_new[j] > energy_temp_new[energy_j]:
				energy_sort = energy_sort + 1
		# 当前能量排序 denergy_sort 和能量值
		[energy_temp_new[j], energy_sort]

		# 定义邻域节点集合(第一行存储邻域节点标号
		# 第二行存储邻域节点对应的能量)
		neighbor = []
		neighbor_number = []
		# print "X[0][i][j] =", X[0][i][j]
		for p in range(0, region[0][i]):
			# 说明节点j与k在x_hop内可达，表明k为节点j的邻域节点
			if X[0][i][j][p] == 1:
				# 得到邻域节点的标号,需要考虑它时实际的标号吗？
				neighbor_number.append(p)

		# 此时已经得到领域节点集合 neighbor
		# 计算邻域节点集合中最小能量值，每个节点对应一个最小能量值
		# 将其存储在minEnergy矩阵中
		neighbor_energy = []
		# 邻域节点个数
		col = len(neighbor_number)
		# print "col =", col
		# 表明节点j为孤立点
		if col == 0:
			# neighbor_energy.append(0)
			# minEnergy[0][i][0][j] = 0
			minEnergy_temp[0][j] = 0
		# 表明节点j至少存在1个邻域节点
		else:
			for jj in range(0, col):
				neighbor_energy.append(Area[0][i][3][neighbor_number[jj]])
				# neighbor[1][jj] = Area[0][i][3][neighbor[0][jj]]
			# print "neighbor_energy =", neighbor_energy
			# print "min(neighbor_energy) =", min(neighbor_energy)
			minEnergy_temp[0][j] = min(neighbor_energy)
		# print "minEnergy_temp[0][j] =\n", minEnergy_temp[0][j]
		# 区域i中个节点邻域最小能量值
		minEnergy[0][i]= minEnergy_temp
		# print "minEnergy[0][i] =\n", minEnergy[0][i]
		
		# 2、计算权重 denisity and minEnergy,按需修改
		# weight_temp[0][j] = density[0][i][0][j] + (minEnergy[0][i][0][j]/100.0)
		weight_temp[0][j] = density_sort + energy_sort
		# 对区域i中所有节点权重进行统计
		weight[0][i] = weight_temp
# print "weight =\n", weight
# 求得权重

# 判断连通分区，就是确定一些节点时独立于另一些节点而存在
for i in range(0, k):
	# 判断网络中连通分支数量
	# 提取区域i中节点间的路由长度
	path_11 = path[0][i]
	# 节点从0号节点开始
	jj = 0
	num_bran = 0
	# 用以存储网络中连通分支
	connected_bran = []
	# 已访问的连通分支节点数
	col_branch = 0
	# 保存已经遍历连通分支的点
	branch = []
	# 确保所有进入子连通区域中
	while col_branch < region[0][i]:
		# 每个区域中连通分支的数目
		num_bran = num_bran + 1
		
		# 证明jj号节点与aa矩阵中的节点连通,查询对应路由表中值与jj号节点距离不为inf的点
		aa = [aaid for aaid, x_value in enumerate(path_11[jj]) if x_value != float('inf')]
		# aa 为节点id
		# 将该连通分支存储在connected_bran中，已经加入jj号节点
		col_aa = len(aa)
		# 记录已经遍历的点
		for jjjj in range(0, col_aa):
			# connected_bran[num_bran][jjjj] = aa[jjjj]
			# 合并已经遍历的点
			branch.append(aa[jjjj])
		# 将为一个连通分支的节点添加进入connected_bran,只能添加aa，因为aa保存的id才与jj连通
		connected_bran.append(aa)
		# 去除重复元素
		branch = np.unique(branch)
		
		# branch = [branch, connected_bran[num_bran]]
		# 统计已经遍历的节点的个数
		col_branch = len(branch)
		# 查询对应路由表中值与jj号节点距离为inf的点
		bb = [bbid for bbid, x_value in enumerate(path_11[jj]) if x_value == float('inf')]
		# bb = find(path_11[jj] == float('inf'))
		if len(bb) != 0:
			jj = bb[0]

	con_bran_all[0][i] = connected_bran

# 构建锚点及移动路径，每个区域的连通分支存储在con_bran_all中
for i in range(0, k):
	# 1、根据con_bran_all, 判断连通分支数目
	# 将区域i的节点权重取出来
	weight_now = weight[0][i]
	# 当前区域内连通分支提取出来
	bran_now = con_bran_all[0][i]
	X_now = X[0][i]
	
	# bran_num为当前区域内连通分支个数
	bran_num = len(bran_now)
	print "bran_num =", bran_num
	# 记录当前分区内锚点个数
	num_anchor = 0
	anchor_set_temp = []
	# 在每个连通分支内选择锚点
	for j in range(0, bran_num):
		# 处理当前分支内节点
		connected = bran_now[j]
		# 对连通分支进行去除重复操作
		print "connected =", connected
		
		# connected = np.unique(connected)
		# connected(connected == 0) = []
		# col_connected表示当前分支内节点个数
		col_connected = len(connected)
		# 记录当前区域内节点具有其所属锚点
		node_num = 0
		connected_weight = np.empty([1, col_connected], dtype = np.float32)
		connected_X = np.empty([col_connected, col_connected], dtype = np.int)
		# 将该连通分支内的节点对应的权重进行提取
		for jj in range(0, col_connected):
			connected_weight[0][jj] = weight_now[0][connected[jj]]
			for jjj in range(0, col_connected):
				connected_X[jj][jjj] = X_now[connected[jj]][connected[jjj]]
		print "connected_X =\n", connected_X
		
		hehe1 = []
		# 判断是否所有节点都被遍历过或者是跟随锚点一起从序列中删除了
		while node_num < col_connected:
			# 将该点加入锚点阵列
			
			anchor_id = [id1 for id1, x_value in enumerate(connected_weight[0]) if x_value == max(connected_weight[0])]
			# [row, col] = find(max(connected_weight) == connected_weight)
			col = anchor_id
			print "col =", col
			# 最大权重的节点不止一个
			col = col[0]
			print "col =", col
			# 考虑正常节点的同时也考虑孤立节点存在
			if connected_weight[0][col] != 0 or col_connected == 1:
				# 以保证下一次不再选择
				connected_weight[0][col] = 0
				# 连通分支内锚点增加
				num_anchor = num_anchor + 1
				print "connected[col] =", connected[col]
				
				anchor_set_temp.append([num_anchor, connected[col]])

				print "connected[col] =\n", connected[col]
				print "connected_X[connected[col] = \n", connected_X[connected[col]]
				print "connected_X[connected[col][0] = \n", connected_X[connected[col]][0]
				print "size(connected_X[connected[col]) =", np.size(connected_X[connected[col]])
				# 提取连通矩阵中为1的点
				hehe = [heheId for heheId, x_value in enumerate(connected_X[connected[col]]) if x_value == 1] 
				
				print "hehe =", hehe

				# 将该节点邻域节点权重记为0，避免出现大片集中的锚点
				col_hehe = len(hehe)
				
				# 将锚点也添加进入序列,因为锚点的标号对应在连通矩阵X中的值为0，无法获取其中在连通矩阵中的位置
				hehe.append(connected[col])

				print "hehe =", hehe
				for kk in range(0, col_hehe + 1):
					hehe1.append(hehe[kk])
					# 权重记为0，可删改代码在这
					connected_weight[0][hehe[kk]] == 0
					# print "type(connected) =", type(connected)
					# print "connected =", connected
					# print "hehe[kk] =", hehe[kk]
					# 做异常处理
					try:
						# print "connected.index(hehe[kk]) =", connected.index(hehe[kk])
						# 看看怎么把跟随锚点序列的节点一起去掉
						# connected.remove(hehe[kk])

						pass
					except ValueError:
						pass
				
				hehe1 = np.unique(hehe1)
				
				# hehe1(hehe1 == 0) = []
				a = len(hehe1)
				hehe_temp = []
				for hehenum in range(0, a):
					hehe_temp.append(hehe1[hehenum])
				hehe1 = hehe_temp
				# 存在重复节点，需要删除重复节点
				# 连通分支中的节点个数
				node_num = a
	anchor_set[0][i] = anchor_set_temp
	print "anchor_set[0][i] =\n", anchor_set[0][i]

print "anchor_set = \n", anchor_set
# 标注锚点

for i in range(0, k):

	if i == 0:
		
		# 作出第一类点的图形
		plt.scatter(Area[0][i][1], Area[0][i][2], s = 5, color = 'k', marker = 's')
		
		anchor = anchor_set[0][i]
		# print "anchor =", anchor
		# hold on
		col_anchor = np.size(anchor, 0)
		# print "col_anchor =", col_anchor
		for j in range(0, col_anchor):
			# print "anchor[j][1] =", anchor[j][1]
			plt.scatter(Area[0][i][1][anchor[j][1]], Area[0][i][2][anchor[j][1]], s = 30, c = 'k')
	
	elif i == 1:
		
		# 作出第二类点的图形
		plt.scatter(Area[0][i][1], Area[0][i][2], s = 5, color = 'b', marker = 'h')
		anchor = anchor_set[0][i]
		# print "anchor =", anchor
		# hold on
		col_anchor = np.size(anchor, 0)
		# print "col_anchor =", col_anchor
		for j in range(0, col_anchor):
			# print "anchor[j][1] =", anchor[j][1]
			plt.scatter(Area[0][i][1][anchor[j][1]], Area[0][i][2][anchor[j][1]], s = 30, c = 'b')
	
	elif i == 2:
		
		# 作出第三类点的图形
		plt.scatter(Area[0][i][1], Area[0][i][2], s = 5, color = 'r', marker = 'p')
		anchor = anchor_set[0][i]
		# print "anchor =", anchor
		# hold on
		col_anchor = np.size(anchor, 0)
		# print "col_anchor =", col_anchor
		for j in range(0, col_anchor):
			# print "anchor[j][1] =", anchor[j][1]
			plt.scatter(Area[0][i][1][anchor[j][1]], Area[0][i][2][anchor[j][1]], s = 30, c = 'r')
	
	elif i == 3:
		
		# 作出第四类点的图形
		plt.scatter(Area[0][i][1], Area[0][i][2], s = 5, color = 'g', marker = '1')
		anchor = anchor_set[0][i]
		# print "anchor =", anchor
		# hold on
		col_anchor = np.size(anchor, 0)
		# print "col_anchor =", col_anchor
		for j in range(0, col_anchor):
			# print "anchor[j][1] =", anchor[j][1]
			plt.scatter(Area[0][i][1][anchor[j][1]], Area[0][i][2][anchor[j][1]], s = 30, c = 'g')
	
plt.show()
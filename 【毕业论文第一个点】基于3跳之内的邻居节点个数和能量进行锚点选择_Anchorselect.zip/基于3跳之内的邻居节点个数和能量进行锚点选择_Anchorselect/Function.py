# encoding: utf-8
import numpy as np 
# 输入：Area 整个网络区域数据，X确定哪个区域，regionX为X区域中节点个数
# 输出：单个区域中所有节点之间的距离
def findDistance(Area, X, regionX):
	Distance_partition = np.empty([regionX, regionX], dtype = np.float32)
	for i in range(0, regionX):
		for j in range(i, regionX):
			'''
			print "Area[X][1][i]", Area[X][1][i]
			print "Area[X][2][i]", Area[X][2][i]
			print "Area[X][1][j]", Area[X][1][j]
			print "Area[X][2][j]", Area[X][2][j]
			'''
			X_list = []
			X_list.append(Area[X][1][i])
			X_list.append(Area[X][1][j])
			Y_list = []
			Y_list.append(Area[X][2][i])
			Y_list.append(Area[X][2][j])
			# 防止出现负数，出现内存溢出
			if X_list[0] >= X_list[1]:
				Xmax = X_list[0]
				Xmin = X_list[1]
			else:
				Xmax = X_list[1]
				Xmin = X_list[0]

			if Y_list[0] >= Y_list[1]:
				Ymax = Y_list[0]
				Ymin = Y_list[1]
			else:
				Ymax = Y_list[1]
				Ymin = Y_list[0]
			'''
			print "Xmax, Xmin", Xmax, Xmin
			print "Ymax, Ymin", Ymax, Ymin
			'''
			Distance_partition[i][j] = np.sqrt(np.power((Xmax - Xmin), 2) + np.power((Ymax - Ymin), 2)) 
			Distance_partition[j][i] = Distance_partition[i][j]
			'''
			print "Distance_partition[i][j]", Distance_partition[i][j]
			print "Distance_partition[j][i]", Distance_partition[j][i]
			''' 
	# print "Distance_partition =", Distance_partition
	return Distance_partition

# 输入：sequencenumber所有节点的坐标，centerpoint 区域中心坐标 ，节点序号由索引值确定, i 为指定区域中心
# 输出：每个节点到区域中心的距离
def FindDistanceByCenterpoint(sequencenumber, centerpoint, i):
	# Distance_partition 为1xsequencenumber.shape[1]的数组 
	Distance_partition = np.empty([1, sequencenumber.shape[1]], dtype = np.float32)
	for j in range(0, sequencenumber.shape[1]):
	
		# 区域中心坐标为
		centerpoint_coordinateX = centerpoint[1][i] 
		centerpoint_coordinateY = centerpoint[2][i]
		# 网络空间的坐标
		AllNetwork_coordinateX = sequencenumber[0][j]
		AllNetwork_coordinateY = sequencenumber[1][j]
		X_list = []
		X_list.append(centerpoint_coordinateX)
		X_list.append(AllNetwork_coordinateX)
		Y_list = []
		Y_list.append(centerpoint_coordinateY)
		Y_list.append(AllNetwork_coordinateY)

		# 为防止出现负数内存溢出
		if X_list[0] >= X_list[1]:
			Xmax = X_list[0]
			Xmin = X_list[1]
		else:
			Xmax = X_list[1]
			Xmin = X_list[0]

		if Y_list[0] >= Y_list[1]:
			Ymax = Y_list[0]
			Ymin = Y_list[1]
		else:
			Ymax = Y_list[1]
			Ymin = Y_list[0]
		'''
		print "Xmax, Xmin", Xmax, Xmin
		print "Ymax, Ymin", Ymax, Ymin
		'''
		Distance_partition[0][j] = np.sqrt(np.power((Xmax - Xmin), 2) + np.power((Ymax - Ymin), 2)) 
		
		'''
		print "Distance_partition[i][j]", Distance_partition[i][j]
		print "Distance_partition[j][i]", Distance_partition[j][i]
		''' 
	# print "Distance_partition =", Distance_partition
	return Distance_partition
# 输入：a为
def mydijkstra(routingArray, centerpoint):
	# print "len(routingArray) =", routingArray.shape
	# routingArray数组为方阵
	n = routingArray.shape[0] 		# 网络中节点个数
	visited = np.zeros([1, n], dtype = np.int) # 未被访问过的节点

	distance = np.empty([1, n], dtype = np.float32) # 用于保存七点到各个顶点之间的距离，一行n列
	
	for i in range(0, n):
		distance[0][i] = float('inf')

	# print "visited =", visited
	# print "distance =", distance

	distance[0][centerpoint] = 0 # 起点到起点的距离为0
	parent = np.zeros([1, n], dtype = np.int) # 父母节点
	# print "distance =", distance
	for i in range(0, n):
		temp = []
		for j in range(0, n):
			temp.append(distance[0][j])
		# enumerate为枚举，visited_num为索引，visited_value为索引对应的值
		# 对应所得id1对应的节点已被标号
		id1 = [visited_num for visited_num, visited_value in enumerate(visited[0]) if visited_value == 1]
		# print "id1 =", id1
		# print "len(id1) =", len(id1)
		for p in range(0, len(id1)):
			temp[id1[p]] = float('inf') # 已标号节点距离替换为无穷
		u = temp.index(min(temp)) # 找到标号值最小的节点
		# print "u =", u
		# np,show()
		visited[0][u] = 1 # 标记已标号的节点
		# 查找未标号的顶点
		id2 = [visited_num for visited_num, visited_value in enumerate(visited[0]) if visited_value == 0]
	 	# print "id2 =", id2
		for v in id2:
			if routingArray[u][v] + distance[0][u] < distance[0][v]:
				distance[0][v] = distance[0][u] + routingArray[u][v] # 修改标号值
				# parent[0][v] = u
	
	
	# 返回结果
	return distance

# 选择排序
def select_sort(A):
	length = len(A)
	print "length =", length
	for position_i in range(0, length - 1):
		min_position = position_i
		for position_j in range(position_i + 1, length):
			if A[min_position][0] > A[position_j][0]:
				min_position = position_j
		tmp = A[min_position]
		A[min_position] = A[position_i]
		A[position_i] = tmp
	return

# 选择排序
def select_sort_Max2Min(A):
	length = len(A)
	print "length =", length
	for position_i in range(0, length - 1):
		max_position = position_i
		for position_j in range(position_i + 1, length):
			if A[max_position][0] < A[position_j][0]:
				max_position = position_j
		tmp = A[max_position]
		A[max_position] = A[position_i]
		A[position_i] = tmp
	return
